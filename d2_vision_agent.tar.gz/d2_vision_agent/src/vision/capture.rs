//! DXGI Desktop Duplication screen capture.
//!
//! Captures the primary display at 25 Hz using the Desktop Duplication API.
//! Extracts FrameState from raw pixel data and pushes to ShardedFrameBuffer.
//!
//! On non-Windows, provides a simulation stub for testing.

use crate::vision::{FrameState, ItemQuality, LootLabel, ShardedFrameBuffer};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;
use std::time::{Duration, Instant};

/// Configuration for the capture pipeline
#[derive(Debug, Clone)]
pub struct CaptureConfig {
    /// Target frames per second (default 25)
    pub target_fps: u32,
    /// Game window title to find (for windowed mode)
    pub window_title: String,
    /// Screen region to capture (x, y, width, height) — None = full primary
    pub region: Option<(u32, u32, u32, u32)>,
    /// HP orb center position (relative to game window)
    pub hp_orb_center: (u32, u32),
    /// Mana orb center position
    pub mana_orb_center: (u32, u32),
    /// HP orb sample radius in pixels
    pub orb_sample_radius: u32,
    /// Character center screen position
    pub char_center: (u16, u16),
}

impl Default for CaptureConfig {
    fn default() -> Self {
        // Default positions for 800x600 D2 resolution
        Self {
            target_fps: 25,
            window_title: "Diablo II".to_string(),
            region: None,
            hp_orb_center: (95, 525),     // Left orb
            mana_orb_center: (705, 525),   // Right orb
            orb_sample_radius: 30,
            char_center: (400, 300),
        }
    }
}

/// Raw pixel buffer from screen capture
pub struct CapturedFrame {
    pub pixels: Vec<u8>, // BGRA format, row-major
    pub width: u32,
    pub height: u32,
    pub stride: u32,      // bytes per row (may include padding)
    pub timestamp: Instant,
}

/// The capture pipeline. Runs in its own thread, pushes to ShardedFrameBuffer.
pub struct CapturePipeline {
    config: CaptureConfig,
    buffer: Arc<ShardedFrameBuffer>,
    running: Arc<AtomicBool>,
    tick: u64,
}

impl CapturePipeline {
    pub fn new(config: CaptureConfig, buffer: Arc<ShardedFrameBuffer>) -> Self {
        Self {
            config,
            buffer,
            running: Arc::new(AtomicBool::new(false)),
            tick: 0,
        }
    }

    pub fn running_flag(&self) -> Arc<AtomicBool> {
        Arc::clone(&self.running)
    }

    /// Run the capture loop. Blocks until running flag is set to false.
    pub fn run(&mut self) {
        self.running.store(true, Ordering::Release);
        let frame_interval = Duration::from_micros(1_000_000 / self.config.target_fps as u64);

        #[cfg(windows)]
        let mut capturer = match DxgiCapturer::new() {
            Ok(c) => c,
            Err(e) => {
                tracing::error!("Failed to initialize DXGI capture: {}", e);
                self.running.store(false, Ordering::Release);
                return;
            }
        };

        while self.running.load(Ordering::Acquire) {
            let frame_start = Instant::now();

            #[cfg(windows)]
            let capture_result = capturer.capture_frame();
            #[cfg(not(windows))]
            let capture_result = self.simulate_capture();

            match capture_result {
                Ok(frame) => {
                    let state = self.extract_frame_state(&frame);
                    self.buffer.push(state);
                    self.tick += 1;
                }
                Err(_) => {
                    // Frame skip — DXGI returns timeout if no screen update
                    // This is normal behavior, not an error
                }
            }

            // Precise frame timing
            let elapsed = frame_start.elapsed();
            if elapsed < frame_interval {
                std::thread::sleep(frame_interval - elapsed);
            }
        }
    }

    /// Extract FrameState from raw pixel data
    fn extract_frame_state(&self, frame: &CapturedFrame) -> FrameState {
        let mut state = FrameState::default();
        state.tick = self.tick;
        state.capture_time_ns = frame.timestamp.elapsed().as_nanos() as u64;
        state.char_screen_x = self.config.char_center.0 as u16;
        state.char_screen_y = self.config.char_center.1 as u16;

        // Read HP orb
        state.hp_pct = self.read_orb_pct(
            frame,
            self.config.hp_orb_center,
            OrbType::Health,
        );

        // Read Mana orb
        state.mana_pct = self.read_orb_pct(
            frame,
            self.config.mana_orb_center,
            OrbType::Mana,
        );

        // Detect enemies in the playfield area
        state.enemy_count = self.count_enemies(frame);
        state.in_combat = state.enemy_count > 0;

        // Detect ground loot labels
        let labels = self.detect_loot_labels(frame);
        state.loot_label_count = labels.len() as u8;
        for (i, label) in labels.iter().enumerate().take(8) {
            state.loot_labels[i] = label.clone();
        }

        // Detect town (stone floor colors vs dungeon/field)
        state.in_town = self.detect_town(frame);

        // Merc alive check (green health bar above merc portrait)
        state.merc_alive = self.detect_merc_alive(frame);

        state
    }

    // ─── Orb Reading ───────────────────────────────────────────

    fn read_orb_pct(&self, frame: &CapturedFrame, center: (u32, u32), orb_type: OrbType) -> u8 {
        let r = self.config.orb_sample_radius;
        let (cx, cy) = center;

        // Sample vertical column through orb center
        // D2 orbs fill from bottom to top
        let mut filled_pixels = 0u32;
        let mut total_pixels = 0u32;

        let (target_r, target_g, target_b, threshold) = match orb_type {
            OrbType::Health => (180, 20, 20, 60), // Red orb
            OrbType::Mana => (30, 30, 180, 60),    // Blue orb
        };

        for dy in 0..r * 2 {
            let y = cy.saturating_sub(r) + dy;
            // Sample a few columns for robustness
            for dx_offset in [0i32, -3, 3, -6, 6] {
                let x = (cx as i32 + dx_offset).max(0) as u32;
                if x >= frame.width || y >= frame.height {
                    continue;
                }

                let idx = (y * frame.stride + x * 4) as usize;
                if idx + 2 >= frame.pixels.len() {
                    continue;
                }

                let b = frame.pixels[idx] as i32;
                let g = frame.pixels[idx + 1] as i32;
                let pixel_r = frame.pixels[idx + 2] as i32;

                total_pixels += 1;

                // Check if pixel matches orb color
                let dist = ((pixel_r - target_r).pow(2)
                    + (g - target_g).pow(2)
                    + (b - target_b).pow(2)) as f32;
                if dist.sqrt() < threshold as f32 {
                    filled_pixels += 1;
                }
            }
        }

        if total_pixels == 0 {
            return 100; // Can't read = assume full (safer)
        }

        ((filled_pixels as f32 / total_pixels as f32) * 100.0).min(100.0) as u8
    }

    // ─── Enemy Detection ───────────────────────────────────────

    fn count_enemies(&self, frame: &CapturedFrame) -> u8 {
        // Detect enemy health bars: thin red horizontal bars above enemy heads
        // Health bars in D2 are bright red (255, 0, 0) or dark red for damaged
        // They appear in the playfield area (y: 50..450 for 800x600)
        let mut bar_count = 0u8;
        let scan_y_start = (frame.height as f32 * 0.08) as u32;
        let scan_y_end = (frame.height as f32 * 0.75) as u32;
        let step = 4; // Sample every 4th row for speed

        let mut last_bar_y = 0u32;

        for y in (scan_y_start..scan_y_end).step_by(step) {
            let mut red_run = 0u32;
            for x in (50..frame.width.saturating_sub(50)).step_by(2) {
                let idx = (y * frame.stride + x * 4) as usize;
                if idx + 2 >= frame.pixels.len() {
                    continue;
                }

                let b = frame.pixels[idx];
                let g = frame.pixels[idx + 1];
                let r = frame.pixels[idx + 2];

                // Enemy health bar: bright red, low green/blue
                if r > 180 && g < 60 && b < 60 {
                    red_run += 1;
                } else {
                    // A health bar is typically 20-40 pixels wide
                    if red_run >= 10 && red_run <= 50 && y.saturating_sub(last_bar_y) > 20 {
                        bar_count = bar_count.saturating_add(1);
                        last_bar_y = y;
                    }
                    red_run = 0;
                }
            }
        }

        bar_count.min(20) // Cap at 20
    }

    // ─── Loot Detection ────────────────────────────────────────

    fn detect_loot_labels(&self, frame: &CapturedFrame) -> Vec<LootLabel> {
        // D2 ground item labels appear as colored text on screen
        // Scan for clusters of quality-colored pixels
        let mut labels = Vec::new();

        // Quality color definitions (BGRA order in memory)
        let quality_colors: [(u8, u8, u8, ItemQuality, u32); 6] = [
            (99, 166, 198, ItemQuality::Unique, 35),   // Gold text
            (0, 255, 0, ItemQuality::Set, 30),           // Green text
            (119, 255, 255, ItemQuality::Rare, 25),      // Yellow text
            (255, 104, 104, ItemQuality::Magic, 25),     // Blue text (BGR)
            (80, 169, 255, ItemQuality::Rune, 30),       // Orange text
            (255, 255, 255, ItemQuality::Normal, 20),    // White text
        ];

        // Scan playfield area for colored text clusters
        let scan_y_start = (frame.height as f32 * 0.10) as u32;
        let scan_y_end = (frame.height as f32 * 0.75) as u32;
        let step = 6;

        for y in (scan_y_start..scan_y_end).step_by(step) {
            for x in (20..frame.width.saturating_sub(20)).step_by(8) {
                let idx = (y * frame.stride + x * 4) as usize;
                if idx + 2 >= frame.pixels.len() {
                    continue;
                }

                let pb = frame.pixels[idx];
                let pg = frame.pixels[idx + 1];
                let pr = frame.pixels[idx + 2];

                for &(tb, tg, tr, ref quality, threshold) in &quality_colors {
                    let dist = ((pr as i32 - tr as i32).pow(2)
                        + (pg as i32 - tg as i32).pow(2)
                        + (pb as i32 - tb as i32).pow(2)) as f32;

                    if dist.sqrt() < threshold as f32 {
                        // Check for cluster (adjacent colored pixels = likely text)
                        let cluster = self.check_text_cluster(frame, x, y, tr, tg, tb, threshold);
                        if cluster >= 3 {
                            // Avoid duplicates near same position
                            let too_close = labels.iter().any(|l: &LootLabel| {
                                (l.x as i32 - x as i32).abs() < 40
                                    && (l.y as i32 - y as i32).abs() < 15
                            });
                            if !too_close {
                                labels.push(LootLabel {
                                    x: x as u16,
                                    y: y as u16,
                                    quality: quality.clone(),
                                    text_hash: (x * 31 + y * 17) as u32,
                                });
                            }
                        }
                        break; // Only match first quality
                    }
                }
            }
        }

        labels.truncate(8); // Max 8 labels per frame
        labels
    }

    fn check_text_cluster(
        &self,
        frame: &CapturedFrame,
        cx: u32, cy: u32,
        tr: u8, tg: u8, tb: u8,
        threshold: u32,
    ) -> u32 {
        let mut count = 0u32;
        for dy in -2i32..=2 {
            for dx in -4i32..=4 {
                let x = (cx as i32 + dx * 2).max(0) as u32;
                let y = (cy as i32 + dy).max(0) as u32;
                if x >= frame.width || y >= frame.height {
                    continue;
                }
                let idx = (y * frame.stride + x * 4) as usize;
                if idx + 2 >= frame.pixels.len() {
                    continue;
                }
                let dist = ((frame.pixels[idx + 2] as i32 - tr as i32).pow(2)
                    + (frame.pixels[idx + 1] as i32 - tg as i32).pow(2)
                    + (frame.pixels[idx] as i32 - tb as i32).pow(2)) as f32;
                if dist.sqrt() < threshold as f32 {
                    count += 1;
                }
            }
        }
        count
    }

    // ─── Town Detection ────────────────────────────────────────

    fn detect_town(&self, frame: &CapturedFrame) -> bool {
        // Town areas have characteristic stone/tan floor colors
        // Sample the lower-center of screen (character's feet area)
        let sample_y = (frame.height as f32 * 0.55) as u32;
        let sample_x_start = (frame.width as f32 * 0.35) as u32;
        let sample_x_end = (frame.width as f32 * 0.65) as u32;

        let mut town_pixels = 0u32;
        let mut total = 0u32;

        for x in (sample_x_start..sample_x_end).step_by(4) {
            for dy in 0..20u32 {
                let y = sample_y + dy;
                let idx = (y * frame.stride + x * 4) as usize;
                if idx + 2 >= frame.pixels.len() {
                    continue;
                }
                let b = frame.pixels[idx];
                let g = frame.pixels[idx + 1];
                let r = frame.pixels[idx + 2];

                total += 1;

                // Town stone colors: warm gray/tan (roughly equal RGB, moderate brightness)
                let avg = (r as u32 + g as u32 + b as u32) / 3;
                let max_diff = r.max(g).max(b) as i32 - r.min(g).min(b) as i32;
                if avg > 80 && avg < 180 && max_diff < 40 {
                    town_pixels += 1;
                }
            }
        }

        total > 0 && (town_pixels as f32 / total as f32) > 0.35
    }

    // ─── Merc Detection ────────────────────────────────────────

    fn detect_merc_alive(&self, frame: &CapturedFrame) -> bool {
        // Merc health bar is at the top-left of screen, below character portrait
        // Small green bar around (10, 80) for 800x600
        let bar_y = (frame.height as f32 * 0.13) as u32;
        let bar_x_start = 10u32;
        let bar_x_end = 80u32;
        let mut green_count = 0u32;

        for x in bar_x_start..bar_x_end {
            let idx = (bar_y * frame.stride + x * 4) as usize;
            if idx + 2 >= frame.pixels.len() {
                continue;
            }
            let g = frame.pixels[idx + 1];
            let r = frame.pixels[idx + 2];
            let b = frame.pixels[idx];
            if g > 150 && r < 80 && b < 80 {
                green_count += 1;
            }
        }

        green_count > 10
    }

    // ─── Simulation (non-Windows) ──────────────────────────────

    #[cfg(not(windows))]
    fn simulate_capture(&self) -> Result<CapturedFrame, anyhow::Error> {
        // Produce a synthetic frame for testing
        let width = 800u32;
        let height = 600u32;
        let stride = width * 4;
        let mut pixels = vec![0u8; (stride * height) as usize];

        // Paint a basic test scene
        // Red HP orb area
        let (hx, hy) = self.config.hp_orb_center;
        for dy in 0..60u32 {
            for dx in 0..60u32 {
                let x = hx.saturating_sub(30) + dx;
                let y = hy.saturating_sub(30) + dy;
                if x < width && y < height {
                    let idx = (y * stride + x * 4) as usize;
                    if dy < 45 { // 75% filled
                        pixels[idx] = 20;     // B
                        pixels[idx + 1] = 20; // G
                        pixels[idx + 2] = 200; // R
                    }
                }
            }
        }

        // Blue Mana orb area
        let (mx, my) = self.config.mana_orb_center;
        for dy in 0..60u32 {
            for dx in 0..60u32 {
                let x = mx.saturating_sub(30) + dx;
                let y = my.saturating_sub(30) + dy;
                if x < width && y < height {
                    let idx = (y * stride + x * 4) as usize;
                    if dy < 40 { // 67% filled
                        pixels[idx] = 200;    // B
                        pixels[idx + 1] = 30; // G
                        pixels[idx + 2] = 30; // R
                    }
                }
            }
        }

        Ok(CapturedFrame {
            pixels,
            width,
            height,
            stride,
            timestamp: Instant::now(),
        })
    }
}

enum OrbType {
    Health,
    Mana,
}

// ═══════════════════════════════════════════════════════════════
// Windows DXGI Desktop Duplication
// ═══════════════════════════════════════════════════════════════

#[cfg(windows)]
pub struct DxgiCapturer {
    device: windows::Win32::Graphics::Direct3D11::ID3D11Device,
    context: windows::Win32::Graphics::Direct3D11::ID3D11DeviceContext,
    duplication: windows::Win32::Graphics::Dxgi::IDXGIOutputDuplication,
    width: u32,
    height: u32,
}

#[cfg(windows)]
impl DxgiCapturer {
    pub fn new() -> anyhow::Result<Self> {
        use windows::Win32::Graphics::Direct3D::*;
        use windows::Win32::Graphics::Direct3D11::*;
        use windows::Win32::Graphics::Dxgi::*;

        unsafe {
            // Create D3D11 device
            let mut device = None;
            let mut context = None;
            D3D11CreateDevice(
                None,
                D3D_DRIVER_TYPE_HARDWARE,
                None,
                D3D11_CREATE_DEVICE_FLAG(0),
                Some(&[D3D_FEATURE_LEVEL_11_0]),
                D3D11_SDK_VERSION,
                Some(&mut device),
                None,
                Some(&mut context),
            )?;

            let device = device.ok_or_else(|| anyhow::anyhow!("No D3D11 device"))?;
            let context = context.ok_or_else(|| anyhow::anyhow!("No D3D11 context"))?;

            // Get DXGI device → adapter → output
            let dxgi_device: IDXGIDevice = device.cast()?;
            let adapter = dxgi_device.GetAdapter()?;
            let output: IDXGIOutput = adapter.EnumOutputs(0)?;
            let output1: IDXGIOutput1 = output.cast()?;

            // Get output description for dimensions
            let desc = output.GetDesc()?;
            let width = (desc.DesktopCoordinates.right - desc.DesktopCoordinates.left) as u32;
            let height = (desc.DesktopCoordinates.bottom - desc.DesktopCoordinates.top) as u32;

            // Create duplication
            let duplication = output1.DuplicateOutput(&device)?;

            Ok(Self {
                device,
                context,
                duplication,
                width,
                height,
            })
        }
    }

    pub fn capture_frame(&mut self) -> anyhow::Result<CapturedFrame> {
        use windows::Win32::Graphics::Direct3D11::*;
        use windows::Win32::Graphics::Dxgi::*;

        unsafe {
            let mut frame_info = DXGI_OUTDUPL_FRAME_INFO::default();
            let mut resource = None;

            // Try to acquire frame (16ms timeout = ~60fps max)
            self.duplication
                .AcquireNextFrame(16, &mut frame_info, &mut resource)
                .map_err(|e| anyhow::anyhow!("AcquireNextFrame: {}", e))?;

            let resource = resource.ok_or_else(|| anyhow::anyhow!("No resource"))?;
            let texture: ID3D11Texture2D = resource.cast()?;

            // Create staging texture for CPU read
            let mut desc = D3D11_TEXTURE2D_DESC::default();
            texture.GetDesc(&mut desc);
            desc.Usage = D3D11_USAGE_STAGING;
            desc.BindFlags = D3D11_BIND_FLAG(0);
            desc.CPUAccessFlags = D3D11_CPU_ACCESS_READ;
            desc.MiscFlags = D3D11_RESOURCE_MISC_FLAG(0);

            let staging = self.device.CreateTexture2D(&desc, None)?;
            self.context.CopyResource(&staging, &texture);

            // Map and read pixels
            let mut mapped = D3D11_MAPPED_SUBRESOURCE::default();
            self.context.Map(
                &staging,
                0,
                D3D11_MAP_READ,
                0,
                Some(&mut mapped),
            )?;

            let stride = mapped.RowPitch;
            let total_bytes = (stride * self.height) as usize;
            let pixels = std::slice::from_raw_parts(
                mapped.pData as *const u8,
                total_bytes,
            ).to_vec();

            self.context.Unmap(&staging, 0);
            self.duplication.ReleaseFrame()?;

            Ok(CapturedFrame {
                pixels,
                width: self.width,
                height: self.height,
                stride,
                timestamp: Instant::now(),
            })
        }
    }
}
